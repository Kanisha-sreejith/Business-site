# Apex Studio — Business Landing Page
> **Stack:** Spring Boot 3 (Java 17) · React 18 · Vite · Axios

A full-stack business landing page with a Spring Boot REST API backend and a React frontend. Features a polished dark UI with services, stats, testimonials, and a working contact form.

---

## Project Structure

```
business-site/
├── backend/                  # Spring Boot application
│   ├── pom.xml
│   └── src/main/java/com/business/site/
│       ├── BusinessSiteApplication.java
│       ├── WebConfig.java            ← CORS configuration
│       ├── controller/
│       │   ├── SiteController.java   ← GET /api/services, /stats, /testimonials
│       │   ├── ContactController.java← POST /api/contact
│       │   └── GlobalExceptionHandler.java
│       ├── model/
│       │   ├── ContactRequest.java
│       │   ├── ServiceInfo.java
│       │   └── ApiResponse.java
│       └── service/
│           └── ContactService.java
│
└── frontend/                 # React + Vite application
    ├── index.html
    ├── vite.config.js        ← proxies /api → localhost:8080
    ├── package.json
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── api.js            ← Axios client
        ├── styles/
        │   └── global.css
        └── components/
            ├── Navbar.jsx / .css
            ├── Hero.jsx / .css
            ├── Stats.jsx / .css
            ├── Services.jsx / .css
            ├── About.jsx / .css
            ├── Testimonials.jsx / .css
            ├── Contact.jsx / .css
            └── Footer.jsx / .css
```

---

## Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- Node.js 18+

### 1 — Start the Backend

```bash
cd backend
./mvnw spring-boot:run
# API available at http://localhost:8080
```

### 2 — Start the Frontend (new terminal)

```bash
cd frontend
npm install
npm run dev
# Site available at http://localhost:3000
```

The Vite dev server proxies all `/api/*` requests to the Spring Boot backend automatically.

---

## API Endpoints

| Method | Path                | Description                     |
|--------|---------------------|---------------------------------|
| GET    | /api/services       | List of company services        |
| GET    | /api/stats          | Key business statistics         |
| GET    | /api/testimonials   | Client testimonials             |
| POST   | /api/contact        | Submit contact form             |

### Contact Form Payload

```json
{
  "name": "Jane Smith",
  "email": "jane@company.com",
  "subject": "Project Inquiry",
  "message": "Tell us about your project..."
}
```

---

## Customisation

### Branding
- Edit company name and copy in each React component
- Update CSS variables in `src/styles/global.css` (colours, fonts)
- Replace `▲` logo with an SVG icon or image

### Email (Contact Form)
In `ContactService.java`, uncomment the `JavaMailSender` block and configure:

```properties
# application.properties
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
```

### Production Build

```bash
# Build the React app
cd frontend && npm run build

# Copy dist/ into backend/src/main/resources/static/
# Then run the jar — Spring Boot will serve the frontend too
cd ../backend && ./mvnw package
java -jar target/site-1.0.0.jar
```

---

## Tech Stack

| Layer     | Technology              |
|-----------|-------------------------|
| Backend   | Spring Boot 3, Java 17  |
| Validation| Jakarta Bean Validation |
| Frontend  | React 18, Vite 5        |
| HTTP      | Axios                   |
| Fonts     | Playfair Display, DM Sans|
| Build     | Maven (BE), Vite (FE)   |
