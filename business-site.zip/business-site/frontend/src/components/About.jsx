import './About.css'

const values = [
  { title: 'Obsessive Quality', desc: 'We hold every deliverable to an unreasonable standard.' },
  { title: 'Radical Transparency', desc: 'You always know where we stand — good or bad.' },
  { title: 'Speed with Intent', desc: 'We move fast, but never at the cost of craftsmanship.' },
]

export default function About() {
  return (
    <section className="section about-section" id="about">
      <div className="container about-grid">
        <div className="about-visual">
          <div className="about-card main-card">
            <span className="about-card-icon">▲</span>
            <p className="about-card-label">Apex Studio</p>
            <p className="about-card-sub">Est. 2012 · San Francisco</p>
          </div>
          <div className="about-card accent-card">
            <p className="about-card-big">98%</p>
            <p className="about-card-desc">Client retention rate</p>
          </div>
          <div className="about-card muted-card">
            <p className="about-card-big">4.9★</p>
            <p className="about-card-desc">Average client score</p>
          </div>
        </div>

        <div className="about-text">
          <p className="section-label">Who We Are</p>
          <h2 className="section-title">
            Built by Builders,<br />
            <em>for Builders</em>
          </h2>
          <p className="section-subtitle" style={{marginBottom: '40px'}}>
            We started Apex Studio because we were frustrated by agencies that
            promised strategy but delivered slide decks. Today, we're a team of
            80+ engineers, designers, and operators who have built companies from
            the ground up.
          </p>

          <div className="values-list">
            {values.map((v, i) => (
              <div className="value-item" key={i}>
                <div className="value-dot" />
                <div>
                  <h4 className="value-title">{v.title}</h4>
                  <p className="value-desc">{v.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
