import './Hero.css'

export default function Hero() {
  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })

  return (
    <section className="hero" id="hero">
      <div className="hero-bg">
        <div className="orb orb-1" />
        <div className="orb orb-2" />
        <div className="grid-overlay" />
      </div>

      <div className="container hero-content">
        <p className="section-label fade-up delay-1">Strategy · Product · Technology</p>

        <h1 className="hero-title fade-up delay-2">
          We Build the<br />
          <em>Businesses</em> of<br />
          Tomorrow
        </h1>

        <p className="hero-sub fade-up delay-3">
          Apex Studio partners with ambitious founders and enterprises to
          design, build, and scale products that define categories.
        </p>

        <div className="hero-actions fade-up delay-4">
          <button className="btn-primary" onClick={() => scrollTo('contact')}>
            Start a Project →
          </button>
          <button className="btn-outline" onClick={() => scrollTo('services')}>
            See Our Work
          </button>
        </div>

        <div className="hero-badges fade-up delay-5">
          <span className="badge">✓ 500+ Clients</span>
          <span className="badge">✓ 12 Years Experience</span>
          <span className="badge">✓ Trusted Globally</span>
        </div>
      </div>

      <div className="scroll-hint">
        <span>Scroll</span>
        <div className="scroll-line" />
      </div>
    </section>
  )
}
