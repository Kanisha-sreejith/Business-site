import './Footer.css'

export default function Footer() {
  const year = new Date().getFullYear()
  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div className="footer-brand">
            <p className="footer-logo">
              <span>▲</span> Apex Studio
            </p>
            <p className="footer-tagline">
              Building businesses that define categories.
            </p>
          </div>

          <div className="footer-links-group">
            <p className="footer-links-title">Company</p>
            <ul>
              {['Services', 'About', 'Testimonials', 'Contact'].map(l => (
                <li key={l}>
                  <button onClick={() => scrollTo(l.toLowerCase())}>{l}</button>
                </li>
              ))}
            </ul>
          </div>

          <div className="footer-links-group">
            <p className="footer-links-title">Connect</p>
            <ul>
              <li><a href="#" target="_blank" rel="noreferrer">LinkedIn</a></li>
              <li><a href="#" target="_blank" rel="noreferrer">Twitter / X</a></li>
              <li><a href="#" target="_blank" rel="noreferrer">GitHub</a></li>
              <li><a href="mailto:hello@apexstudio.com">Email Us</a></li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>© {year} Apex Studio, Inc. All rights reserved.</p>
          <div className="footer-legal">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
