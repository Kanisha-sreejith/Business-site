import { useState } from 'react'
import { submitContact } from '../api'
import './Contact.css'

const INITIAL = { name: '', email: '', subject: '', message: '' }

export default function Contact() {
  const [form, setForm] = useState(INITIAL)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState(null) // 'loading' | 'success' | 'error'
  const [serverMessage, setServerMessage] = useState('')

  const onChange = (e) => {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))
    setErrors(err => ({ ...err, [e.target.name]: '' }))
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    setStatus('loading')
    setErrors({})

    try {
      const res = await submitContact(form)
      setStatus('success')
      setServerMessage(res.message)
      setForm(INITIAL)
    } catch (err) {
      setStatus('error')
      if (err.response?.data?.data) {
        setErrors(err.response.data.data)
        setServerMessage(err.response.data.message || 'Please fix the errors below.')
      } else {
        setServerMessage('Something went wrong. Please try again.')
      }
    }
  }

  return (
    <section className="section contact-section" id="contact">
      <div className="container">
        <div className="contact-grid">
          <div className="contact-info">
            <p className="section-label">Get In Touch</p>
            <h2 className="section-title">
              Let's Build<br /><em>Something Great</em>
            </h2>
            <p className="section-subtitle" style={{ marginBottom: 40 }}>
              Tell us about your project. We read every message and respond
              within one business day.
            </p>

            <div className="contact-details">
              <div className="contact-detail">
                <span className="detail-icon">📍</span>
                <div>
                  <p className="detail-title">Office</p>
                  <p className="detail-text">548 Market St, San Francisco, CA 94104</p>
                </div>
              </div>
              <div className="contact-detail">
                <span className="detail-icon">✉️</span>
                <div>
                  <p className="detail-title">Email</p>
                  <p className="detail-text">hello@apexstudio.com</p>
                </div>
              </div>
              <div className="contact-detail">
                <span className="detail-icon">📞</span>
                <div>
                  <p className="detail-title">Phone</p>
                  <p className="detail-text">+1 (415) 000-0000</p>
                </div>
              </div>
            </div>
          </div>

          <div className="contact-form-wrapper">
            {status === 'success' ? (
              <div className="success-state">
                <div className="success-icon">✓</div>
                <h3>Message Sent!</h3>
                <p>{serverMessage}</p>
                <button className="btn-outline" onClick={() => setStatus(null)}>
                  Send Another
                </button>
              </div>
            ) : (
              <form className="contact-form" onSubmit={onSubmit} noValidate>
                <div className="form-row">
                  <div className={`form-field ${errors.name ? 'has-error' : ''}`}>
                    <label htmlFor="name">Full Name</label>
                    <input
                      id="name" name="name" type="text"
                      placeholder="Jane Smith"
                      value={form.name} onChange={onChange}
                    />
                    {errors.name && <span className="field-error">{errors.name}</span>}
                  </div>
                  <div className={`form-field ${errors.email ? 'has-error' : ''}`}>
                    <label htmlFor="email">Email Address</label>
                    <input
                      id="email" name="email" type="email"
                      placeholder="jane@company.com"
                      value={form.email} onChange={onChange}
                    />
                    {errors.email && <span className="field-error">{errors.email}</span>}
                  </div>
                </div>

                <div className={`form-field ${errors.subject ? 'has-error' : ''}`}>
                  <label htmlFor="subject">Subject</label>
                  <input
                    id="subject" name="subject" type="text"
                    placeholder="What are you looking to build?"
                    value={form.subject} onChange={onChange}
                  />
                  {errors.subject && <span className="field-error">{errors.subject}</span>}
                </div>

                <div className={`form-field ${errors.message ? 'has-error' : ''}`}>
                  <label htmlFor="message">Message</label>
                  <textarea
                    id="message" name="message" rows={5}
                    placeholder="Tell us about your project, timeline, and budget..."
                    value={form.message} onChange={onChange}
                  />
                  {errors.message && <span className="field-error">{errors.message}</span>}
                </div>

                {status === 'error' && !Object.keys(errors).length && (
                  <p className="form-error-msg">{serverMessage}</p>
                )}

                <button
                  type="submit"
                  className="btn-primary submit-btn"
                  disabled={status === 'loading'}
                >
                  {status === 'loading' ? 'Sending…' : 'Send Message →'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
