import { useEffect, useState } from 'react'
import { fetchServices } from '../api'
import './Services.css'

export default function Services() {
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchServices()
      .then(r => { setServices(r.data || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  return (
    <section className="section" id="services">
      <div className="container">
        <div className="services-header">
          <p className="section-label">What We Do</p>
          <h2 className="section-title">
            Full-Spectrum<br /><em>Business Solutions</em>
          </h2>
          <p className="section-subtitle">
            From first-principles strategy to shipped product — we cover every
            dimension of building a high-performance business.
          </p>
        </div>

        {loading ? (
          <div className="services-loading">
            {[...Array(6)].map((_, i) => <div className="service-skeleton" key={i} />)}
          </div>
        ) : (
          <div className="services-grid">
            {services.map((s, i) => (
              <div className={`service-card fade-up delay-${(i % 3) + 1}`} key={i}>
                <span className="service-icon">{s.icon}</span>
                <h3 className="service-title">{s.title}</h3>
                <p className="service-desc">{s.description}</p>
                <span className="service-arrow">→</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
