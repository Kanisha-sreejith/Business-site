import { useEffect, useState } from 'react'
import { fetchTestimonials } from '../api'
import './Testimonials.css'

export default function Testimonials() {
  const [testimonials, setTestimonials] = useState([])

  useEffect(() => {
    fetchTestimonials()
      .then(r => setTestimonials(r.data || []))
      .catch(() => {})
  }, [])

  return (
    <section className="section" id="testimonials">
      <div className="container">
        <div className="testi-header">
          <p className="section-label">Client Stories</p>
          <h2 className="section-title">
            Don't Take<br /><em>Our Word For It</em>
          </h2>
        </div>

        <div className="testi-grid">
          {testimonials.map((t, i) => (
            <div className={`testi-card fade-up delay-${i + 1}`} key={i}>
              <div className="quote-mark">"</div>
              <p className="testi-quote">{t.quote}</p>
              <div className="testi-author">
                <div className="testi-avatar">{t.avatar}</div>
                <div>
                  <p className="testi-name">{t.name}</p>
                  <p className="testi-role">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
