import { useEffect, useState } from 'react'
import { fetchStats } from '../api'
import './Stats.css'

export default function Stats() {
  const [stats, setStats] = useState([])

  useEffect(() => {
    fetchStats()
      .then(r => setStats(r.data || []))
      .catch(() => setStats([
        { label: 'Clients Served', value: '500+' },
        { label: 'Projects Delivered', value: '1,200+' },
        { label: 'Years of Experience', value: '12' },
        { label: 'Team Members', value: '80+' },
      ]))
  }, [])

  return (
    <section className="stats-section">
      <div className="container">
        <div className="stats-grid">
          {stats.map((s, i) => (
            <div className="stat-card" key={i}>
              <span className="stat-value">{s.value}</span>
              <span className="stat-label">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
