import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 10000,
})

export const fetchServices = () => api.get('/services').then(r => r.data)
export const fetchStats = () => api.get('/stats').then(r => r.data)
export const fetchTestimonials = () => api.get('/testimonials').then(r => r.data)
export const submitContact = (data) => api.post('/contact', data).then(r => r.data)

export default api
