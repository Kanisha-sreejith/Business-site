package com.business.site.controller;

import com.business.site.model.ApiResponse;
import com.business.site.model.ContactRequest;
import com.business.site.service.ContactService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contact")
public class ContactController {

    private final ContactService contactService;

    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Void>> submitContact(
            @Valid @RequestBody ContactRequest request) {
        contactService.processContact(request);
        return ResponseEntity.ok(
                ApiResponse.success("Thank you! We'll be in touch within 24 hours.")
        );
    }
}
