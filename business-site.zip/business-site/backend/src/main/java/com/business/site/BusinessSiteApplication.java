package com.business.site;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessSiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(BusinessSiteApplication.class, args);
    }
}
