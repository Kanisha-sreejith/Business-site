package com.business.site.controller;

import com.business.site.model.ApiResponse;
import com.business.site.model.ServiceInfo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SiteController {

    @GetMapping("/services")
    public ResponseEntity<ApiResponse<List<ServiceInfo>>> getServices() {
        List<ServiceInfo> services = List.of(
                new ServiceInfo("💡", "Strategy & Consulting",
                        "We craft data-driven strategies that accelerate growth and sharpen your competitive edge."),
                new ServiceInfo("🚀", "Product Development",
                        "From MVP to scale — we build robust digital products your customers will love."),
                new ServiceInfo("📊", "Analytics & Insights",
                        "Turn raw data into actionable intelligence with our advanced analytics platform."),
                new ServiceInfo("🔐", "Security & Compliance",
                        "Enterprise-grade security solutions that protect your assets and ensure compliance."),
                new ServiceInfo("☁️", "Cloud Infrastructure",
                        "Scalable, resilient cloud architectures designed for performance and cost efficiency."),
                new ServiceInfo("🎨", "Brand & Design",
                        "Memorable visual identities and UX design that communicate your value instantly.")
        );
        return ResponseEntity.ok(ApiResponse.success("Services fetched", services));
    }

    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<List<Map<String, String>>>> getStats() {
        List<Map<String, String>> stats = List.of(
                Map.of("label", "Clients Served", "value", "500+"),
                Map.of("label", "Projects Delivered", "value", "1,200+"),
                Map.of("label", "Years of Experience", "value", "12"),
                Map.of("label", "Team Members", "value", "80+")
        );
        return ResponseEntity.ok(ApiResponse.success("Stats fetched", stats));
    }

    @GetMapping("/testimonials")
    public ResponseEntity<ApiResponse<List<Map<String, String>>>> getTestimonials() {
        List<Map<String, String>> testimonials = List.of(
                Map.of(
                        "name", "Sarah Chen",
                        "role", "CEO, NovaTech",
                        "quote", "Working with this team transformed our digital presence completely. Revenue doubled in six months.",
                        "avatar", "SC"
                ),
                Map.of(
                        "name", "Marcus Webb",
                        "role", "CTO, Orbital Systems",
                        "quote", "Their engineering team delivered a product we thought was impossible on our timeline. Exceptional.",
                        "avatar", "MW"
                ),
                Map.of(
                        "name", "Priya Sharma",
                        "role", "Founder, Bloom Analytics",
                        "quote", "The strategy they built for us is still driving growth two years later. Worth every penny.",
                        "avatar", "PS"
                )
        );
        return ResponseEntity.ok(ApiResponse.success("Testimonials fetched", testimonials));
    }
}
