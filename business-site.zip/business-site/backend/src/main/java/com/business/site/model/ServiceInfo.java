package com.business.site.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ServiceInfo {
    private String icon;
    private String title;
    private String description;
}
