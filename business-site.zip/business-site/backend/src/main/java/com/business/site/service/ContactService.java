package com.business.site.service;

import com.business.site.model.ContactRequest;
import org.springframework.stereotype.Service;

import java.util.logging.Logger;

@Service
public class ContactService {

    private static final Logger log = Logger.getLogger(ContactService.class.getName());

    /**
     * Processes a contact form submission.
     * In production, wire up Spring Mail to send an actual email.
     */
    public void processContact(ContactRequest request) {
        // Log the incoming message (replace with email sending in production)
        log.info("New contact form submission:");
        log.info("  From : " + request.getName() + " <" + request.getEmail() + ">");
        log.info("  Subject: " + request.getSubject());
        log.info("  Message: " + request.getMessage());

        // TODO: inject JavaMailSender and send email to your business address
        // Example:
        // SimpleMailMessage mail = new SimpleMailMessage();
        // mail.setTo("contact@yourbusiness.com");
        // mail.setSubject("[Contact Form] " + request.getSubject());
        // mail.setText("From: " + request.getName() + "\n\n" + request.getMessage());
        // mailSender.send(mail);
    }
}
